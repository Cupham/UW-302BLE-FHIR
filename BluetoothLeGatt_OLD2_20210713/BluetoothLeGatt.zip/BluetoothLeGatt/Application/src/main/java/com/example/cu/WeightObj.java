package com.example.cu;

public class WeightObj {

}
